import boto3
import string
from awsglue.job import Job
from pyspark.context import SparkContext
from pyspark.sql.functions import *
from awsglue.context import GlueContext
import pyspark.sql.functions as f
from pyspark.sql.functions import col, array, when, array_remove
from src.util.helper import (read_parameter_query, load_data_2_rds_custom_mode, read_table, write_data_2_s3, read_ingestion_conf)


s3 = boto3.resource('s3')
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
logger = glueContext.get_logger()
null_rec_count=0

def process_daily_load(job_id:string, conf_bucket:string, conf_file:string):
    conf=read_ingestion_conf(conf_bucket, conf_file)
    concat_columns=conf["concat_columns_stage_table"]
    daily_query=conf["sql_config"]
    stage_df=read_parameter_query(glueContext, daily_query)
    if stage_df.rdd.isEmpty():
        print(f"No data found for After executing Daily SQL.")
        #TODO: Job is failed.
        return

    stage_table=conf["stage_table"]
    daily_table=conf["daily_table"]
    stage_select_columns=conf["select_columns_stage_table"]
    daily_table_df=read_table(glueContext, daily_table)
    daily_table_df_select=daily_table_df.select(*stage_select_columns)
    stage_df_select=stage_df.select(*stage_select_columns)

    daily_table_df_select = daily_table_df_select.withColumn('concatenated_cols',concat_ws("$$", *[col(x) for x in concat_columns]))
    daily_table_df_select = daily_table_df_select.withColumnRenamed('company_name', 'company_name_daily').withColumnRenamed('level_name', 'level_name_daily').withColumnRenamed('acc_id', 'acc_id_daily').withColumnRenamed('acc_name', 'acc_name_daily').withColumnRenamed('bal_dt', 'bal_dt_daily').withColumnRenamed('bal_amt', 'bal_amt_daily')

    stage_df_select = stage_df_select.withColumn('concatenated_cols',concat_ws("$$", *[col(x) for x in concat_columns]))
    stage_df_select = stage_df_select.withColumnRenamed('company_name', 'company_name_stage').withColumnRenamed('level_name', 'level_name_stage').withColumnRenamed('acc_id', 'acc_id_stage').withColumnRenamed('acc_name', 'acc_name_stage').withColumnRenamed('bal_dt', 'bal_dt_stage').withColumnRenamed('bal_amt', 'bal_amt_stage')

    print("Daily DF Counts & Data ******** ")
    daily_table_df_select.show(100, truncate=False)
    print(daily_table_df_select.count())

    print("Stage DF Counts & Data ******** ")
    stage_df_select.show(100, truncate=False)
    print(stage_df_select.count())

    diff_df_left_anti=stage_df_select.join(daily_table_df_select, stage_df_select["concatenated_cols"] == daily_table_df_select["concatenated_cols"], "leftanti")
    print(" DataFrame Left Anti Join. To Get the New/Individual Records. ")
    print(diff_df_left_anti.count())
    diff_df_left_anti.show(100, truncate=False)
    diff_df_left_anti=diff_df_left_anti.withColumn("flag_del", lit("N")).withColumn("last_updt_dt", lit("9999-99-99"))
    print(" New/Individual Records with Flag indicator and Last Update Timestamp. ")
    print(diff_df_left_anti.count())
    diff_df_left_anti.show(100, truncate=False)

    diff_df_left=stage_df_select.join(daily_table_df_select, (stage_df_select.concatenated_cols == daily_table_df_select.concatenated_cols), "left")
    diff_df_left = diff_df_left.withColumn("is_due_amt_updated", when(col("bal_amt_stage") != col("bal_amt_daily"), "YES")
                                           .otherwise("NO"))
    print(" For the Common Records, what ROWS were changed in amount ? ")
    print(diff_df_left.count())
    diff_df_left.show(100, truncate=False)

    daily_updated_df=diff_df_left.filter(diff_df_left['is_due_amt_updated'] == lit("YES")).select("company_name_stage","level_name_stage","acc_id_stage","acc_name_stage","bal_dt_stage","bal_amt_stage")
    daily_expired_df=diff_df_left.filter(diff_df_left['is_due_amt_updated'] == lit("YES")).select("company_name_daily","level_name_daily","acc_id_daily","acc_name_daily","bal_dt_daily","bal_amt_daily")


    daily_updated_df=(daily_updated_df.withColumnRenamed('company_name_stage', 'company_name')
                      .withColumnRenamed('level_name_stage', 'level_name')
                      .withColumnRenamed('acc_id_stage', 'acc_id')
                      .withColumnRenamed('acc_name_stage', 'acc_name')
                      .withColumnRenamed('bal_dt_stage', 'bal_dt')
                      .withColumnRenamed('bal_amt_stage', 'bal_amt')
                      .withColumn("flag_del", lit("N"))
                      .withColumn("last_updt_dt", lit("9999-99-99")))

    print(" Updated Records & Details. ")
    print(daily_updated_df.count())
    daily_updated_df.show(100, truncate=False)

    daily_expired_df=(daily_expired_df.withColumnRenamed('company_name_daily', 'company_name')
                      .withColumnRenamed('level_name_daily', 'level_name')
                      .withColumnRenamed('acc_id_daily', 'acc_id')
                      .withColumnRenamed('acc_name_daily', 'acc_name')
                      .withColumnRenamed('bal_dt_daily', 'bal_dt')
                      .withColumnRenamed('bal_amt_daily', 'bal_amt')
                      .withColumn("flag_del", lit("Y"))
                      .withColumn("last_updt_dt", f.date_format(f.current_timestamp(), 'yyyy-MM-dd')))

    print(" Expired Records & Details. ")
    print(daily_expired_df.count())
    daily_expired_df.show(100, truncate=False)

    print("***************************** Finsh DF before writing to DB ")
    print(" Write Data to DB and Write data to S3 File.")
    #load_data_2_rds_custom_mode(daily_updated_df, daily_table, "")
    #load_data_2_rds_custom_mode(daily_expired_df, daily_table)
    print("************ DB is updated with updated data****************")
    print("************* Data is written to S3 *****************")
    #write_data_2_s3(glueContext, daily_updated_df, conf["s3_destination"])
    #write_data_2_s3(glueContext, daily_expired_df, conf["s3_destination"])
    print("---------------------Daily Job Completed---------------------")

