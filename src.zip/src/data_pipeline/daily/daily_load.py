import string
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
import re
import boto3
from pyspark.sql.dataframe import DataFrame
import pyspark.sql.functions as f
from functools import reduce
from collections import Counter
from src.util.helper import (read_parameter_query, read_ingestion_conf, read_table)
from src.util.db_utils import insert_record, update_record
from src.util.job_tracking import INSERT_SQL, UPDATE_SQL

s3 = boto3.resource('s3')
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
logger = glueContext.get_logger()
null_rec_count=0




# This is where you need to come up with the Select Columns.
# Group Columns.
# This is where you need to go with the
def compare_data_frames(daily_table_df_select:DataFrame, stage_df_select:DataFrame):
    print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
    print()
    joined_df=daily_table_df_select.join(stage_df_select,
                         (daily_table_df_select['company_name'] == stage_df_select['company_name']) &
                         (daily_table_df_select['level_name'] == stage_df_select['level_name']) &
                         (daily_table_df_select['acc_id'] == stage_df_select['acc_id']) &
                         (daily_table_df_select['acc_name'] == stage_df_select['acc_name']) &
                         (daily_table_df_select['bal_dt'] == stage_df_select['bal_dt']))
    print("What are the Common Elements.")
    pass


def process_daily_load(job_id:string, conf_bucket:string, conf_file:string, curr_date:string):
    print("####### Read Config File. ", conf_file)
    print("############################################################")
    daily_load_conf=read_ingestion_conf(conf_bucket, conf_file)
    stage_table=daily_load_conf["table_stage_table"]
    sql_qry=daily_load_conf["sql_config"]
    daily_table=daily_load_conf["table_daily_table"]
    #TODO: Make this Query Parameterized.
    stage_df=read_parameter_query(glueContext, sql_qry)
    # Exception handling in case of empty DataFrame.
    if stage_df.rdd.isEmpty():
        print(f"No data found for {stage_table}")
        #TODO: Job is failed.
        return

    daily_table_df=read_table(glueContext, daily_table)
    stage_select_columns=daily_load_conf["select_columns_stage_table"]
    daily_table_df_select=daily_table_df.select(*stage_select_columns)
    stage_df_select=stage_df.select(*stage_select_columns)
    stage_df_select.show(100)
    print("************************ This is the SELECT ")
    daily_table_df_select.show(100)
    compare_data_frames(daily_table_df_select, stage_df_select)

#/*----------------StagingtoDailyTable----------------*/
#select
#company_name,
#level_name,
#acc_id,
#acc_name,
#bal_dt,
#sum( bal_amt ) as bal_amt
#from STG_FS_BAL_ST
#/*  where file_load_dt = current_date*/
#group by
#company_name,
#level_name,
#acc_id,
#acc_name,
#bal_dt