import datetime
import string
import re
import yaml
import boto3
from awsglue.context import GlueContext
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.types import *
from src.util.json.flatten_json_df import flatten_nested_data
import pyspark.sql.functions as f
from awsglue.dynamicframe import DynamicFrame
from datetime import datetime, timezone
from pyspark.sql.functions import to_json, struct, unix_timestamp, col, regexp_replace, to_timestamp

def provide_datetime():
    val=datetime.now(timezone.utc)
    return val

def provide_datetime_YYYYMMDD():
    val=datetime.datetime.now().strftime('%Y%m%d')
    return val

def add_date_partition_key_to_s3_prefix(s3_prefix):
    t = datetime.today()
    partition_key = f"import_year={t.strftime('%Y')}/import_month={t.strftime('%m')}/import_day={t.strftime('%d')}/import_date={t.strftime('%Y%m%d')}/"  # noqa
    return f"{s3_prefix}{partition_key}"

def read_raw_source_tps_data(glue_context: GlueContext, raw_file_path:string, job_id:string):
    raw_data = glue_context.create_dynamic_frame.from_options(
        connection_type="s3",
        format="csv",
        connection_options={
            "paths": [raw_file_path],
        },
        transformation_ctx="raw_data",
        format_options={
            "withHeader": True,
            "separator": "|"
        })
    raw_data_df = raw_data.toDF()
    raw_data_df=(raw_data_df.withColumn('job_id',f.lit(job_id))
                 .withColumn('file_name',f.lit(raw_file_path))
                 .withColumn('file_load_dt',f.date_format(f.current_timestamp(), 'yyyy-MM-dd')))
    raw_data_df.show(100, truncate=False)
    raw_data_df.printSchema()
    return raw_data_df


def read_raw_source(glue_context: GlueContext, raw_file_path:string, job_id:string):
    raw_data = glue_context.create_dynamic_frame.from_options(
        format_options={
            "multiline": False,
        },
        connection_type="s3",
        format="json",
        connection_options={
            "paths": [raw_file_path],
        },
        transformation_ctx="raw_data",
    )
    raw_data_df = raw_data.toDF()
    raw_data_df_flatten=flatten_nested_data(raw_data_df)
    raw_data_df_final=(raw_data_df_flatten.withColumn('job_id',f.lit(job_id))
                       .withColumn('file_name',f.lit(raw_file_path))
                       .withColumn('file_load_dt',f.date_format(f.current_timestamp(), 'yyyy-MM-dd')))
    raw_data_df_final.show(100, truncate=False)
    return raw_data_df_final


def write_data_2_s3(glue_context: GlueContext, enrich_df:DataFrame, location:string):
    #Convert from Spark Data Frame to Glue Dynamic Frame
    enrich_df.repartition(1).write.mode('overwrite').parquet(location)


def load_data_2_rds(raw_data_df:DataFrame, table_name:string, secret):
    username=secret["username"]
    password=secret["password"]
    url="jdbc:postgresql://"+secret["host"]+":"+secret["port"]+"/"+secret["dbClusterIdentifier"]
    raw_data_df.write \
        .format("jdbc") \
        .option("url", url) \
        .option("dbtable", table_name) \
        .option("user", username) \
        .option("password", password) \
        .option("driver", "org.postgresql.Driver") \
        .mode("append") \
        .save()

def read_ingestion_conf(conf_bucket:string, conf_file:string):
    s3_client = boto3.client('s3')
    response = s3_client.get_object(Bucket=conf_bucket, Key=conf_file)
    try:
        conf = yaml.safe_load(response["Body"])
    except yaml.YAMLError as exc:
        return exc

    return conf

def enrich_data(raw_data_df:DataFrame, raw_2_db_mappings):
    for old_col, new_col in zip(raw_2_db_mappings.keys(), raw_2_db_mappings.values()):
        raw_data_df = raw_data_df.withColumnRenamed(old_col, new_col)

    return raw_data_df

def enrich_datatypes(raw_data_df:DataFrame, raw_2_db_mappings):
    for col_name, cast_type in zip(raw_2_db_mappings.keys(), raw_2_db_mappings.values()):
        if cast_type == 'timestamp':
            print("Coming to TimeStamp Section0----->")
            raw_data_df = raw_data_df.withColumn(col_name, regexp_replace(regexp_replace(raw_data_df[col_name], r'(\b\d\b)', r'0$1'), r'\b(\d+:\d+:\d+)', r'$1'))
            raw_data_df = raw_data_df.withColumn(col_name, unix_timestamp(raw_data_df[col_name], "MM/dd/yyyy hh:mm:ss a").cast("timestamp"))
        else:
            raw_data_df = raw_data_df.withColumn(col_name, raw_data_df[col_name].cast(cast_type))

    return raw_data_df

def read_parameter_query(glue_context: GlueContext, query:string, secret):
    username=secret["username"]
    password=secret["password"]
    url="jdbc:postgresql://"+secret["host"]+":"+secret["port"]+"/"+secret["dbClusterIdentifier"]
    df = glue_context.read.format("jdbc") \
            .option("url", url) \
            .option("query",query) \
            .option("user", username) \
            .option("password", password) \
            .load()
    return df

def read_table(glue_context: GlueContext, table_name:string, secret):
    username=secret["username"]
    password=secret["password"]
    url="jdbc:postgresql://"+secret["host"]+":"+secret["port"]+"/"+secret["dbClusterIdentifier"]
    df = glue_context.read.format("jdbc") \
        .option("url", url) \
        .option("dbtable", table_name) \
        .option("user", username) \
        .option("password", password) \
        .load()
    return df
