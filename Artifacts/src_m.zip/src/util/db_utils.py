import base64
import string
import psycopg2
import boto3
import json
from botocore.exceptions import ClientError
import boto3
from boto3 import client, resource
from json import dumps, loads

runtime_region = "us-east-1"

def get_secret(secret_name:string):
    try:
        obj_ssm_client = client('secretsmanager', region_name=runtime_region)

        get_secret_value_response = obj_ssm_client.get_secret_value(
            SecretId=secret_name
        )
        SecretString = loads(get_secret_value_response["SecretString"])
        print(SecretString)
        return SecretString
    except Exception as e:
        print(e)
