

UPDATE_SQL = """UPDATE layerc_reporting.job_tracking SET total_rec_count=%s, load_rec_count=%s, error_rec_count=%s, end_time=%s, file_path_error=%s, status=%s WHERE job_id=%s """
UPDATE_SQL_DAILY_LOAD = """UPDATE DAILY_FS_BAL_ST_TESTING_V SET flag_del=%s, last_updt_dt=%s WHERE company_name=%s and level_name=%s and acc_id=%s and acc_name=%s and bal_amt=%s and bal_dt=%s """

INSERT_SQL=""" insert into layerc_reporting.job_tracking (job_id,part_of,source, total_rec_count,load_rec_count, error_rec_count,
                    start_time, end_time, source_path, file_path_error, file_path_success, status)
         values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) """

