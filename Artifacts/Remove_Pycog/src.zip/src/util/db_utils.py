import base64
import string
import boto3
import json
from botocore.exceptions import ClientError
import boto3
from boto3 import client, resource
from json import dumps, loads

runtime_region = "us-east-1"

def get_secret(secret_name:string):
    mysql_options = {
        "host": "chellodb.cluster-cb8gwiek2g7m.us-east-2.rds.amazonaws.com",
        "port": "5432",
        "dbClusterIdentifier": "postgres",
        "username": "chellodb",
        "password": "ChelloDB123"
    }
    return mysql_options

